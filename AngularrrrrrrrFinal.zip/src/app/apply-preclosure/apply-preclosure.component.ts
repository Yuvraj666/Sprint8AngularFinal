import { Component, OnInit } from '@angular/core';
import { LoanMaster } from '../model/loan-master';
import { PayEmi } from '../model/pay-emi';
import { PreClosureService } from '../service/pre-closure.service';
import { PreClosure } from '../model/pre-closure';
import { Router } from '@angular/router';
import { Account } from '../model/account';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-apply-preclosure',
  templateUrl: './apply-preclosure.component.html',
  styleUrls: ['./apply-preclosure.component.css']
})
export class ApplyPreclosureComponent implements OnInit {

  userId: string;
  preClosureLoans: LoanMaster[];
  selectedLoan: LoanMaster;
  emiDueLoan: LoanMaster;
  payEmi: PayEmi
  preClosure: PreClosure;
  preClosureLoan: LoanMaster;
  preClosureAccs: Account[];
  preClosureAcc: Account;
  payPreClos:boolean
  loggedInCustomer:Customer;
  displayPreClosureLoans:boolean;
  noLoans:boolean;
  dispSavAcc:boolean;
  preClosureAccSelect:boolean;
  preClosurePaid:boolean;
  updatedLoan:LoanMaster
  preClosLoanSelected:boolean;

  constructor(
    private preClosureServ: PreClosureService,
    private custServ:CustomerService,
    private router: Router
  ) {
  
    this.preClosureLoans = [];
    this.selectedLoan = new LoanMaster();
    this.emiDueLoan = new LoanMaster();
    this.payEmi = new PayEmi();
    this.preClosure = new PreClosure();
    this.preClosureAccs = [];
    this.preClosureAcc = new Account()
    this.payPreClos=false;
    this.loggedInCustomer=new Customer();
    this.displayPreClosureLoans=false;
    this.noLoans=false;
    this.dispSavAcc=false;
    this.preClosureAccSelect=false;
    this.preClosurePaid=false;
    this.updatedLoan=new LoanMaster();
    this.preClosLoanSelected=false;
  }

  ngOnInit() {
    this.loggedInCustomer = this.custServ.loggedInCustomer;
    this.getPreClosureLoans();
  }

  getPreClosureLoans() {
    this.preClosureServ.getPreClosureLoans(this.loggedInCustomer).subscribe(
      (data) => this.preClosureLoans = data
    );
    console.log(this.preClosureLoans.length);
    if (this.preClosureLoans.length > 0) {
      this.displayPreClosureLoans = true;

    } else {
      this.noLoans = true;
    }
  }

  selectLoan(preClosloan:LoanMaster) {
    this.preClosLoanSelected=true;
    this.selectedLoan = preClosloan;
    console.log(this.selectedLoan);
  }

  accChoice() {
    this.dispSavAcc=true;
    this.fetchAccForPreClosure();
  }

  fetchAccForPreClosure() {
    if (this.preClosure.accChoice == "1") {
      this.preClosureServ.fetchAcc(this.selectedLoan).subscribe(
        (data) => this.preClosureAccs = data
      );
    }

    else {
      this.router.navigateByUrl('custDashboard');
    }
  }

  selectPreClosureAcc(selectedAccount: Account) {
    this.preClosureAccSelect = true;
    console.log(this.preClosureAcc.accNo);
    this.preClosureAcc=selectedAccount;
  }

  preClosurePaymentChoice() {
    console.log(this.preClosure.choice);
    if (this.preClosure.choice == "1") {
      this.preClosurePaid=true;
      this.preClosureServ.payPreClosure(this.selectedLoan).subscribe(
        (data) => this.updatedLoan = data
      );
    }

    else {
      this.router.navigateByUrl('custDashboard');
    }
  }

  goBack(){
    this.router.navigateByUrl('custDashboard');
  }
}
