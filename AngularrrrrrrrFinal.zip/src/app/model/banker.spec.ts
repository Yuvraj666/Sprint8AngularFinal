import { Banker } from './banker';

describe('Banker', () => {
  it('should create an instance', () => {
    expect(new Banker()).toBeTruthy();
  });
});
