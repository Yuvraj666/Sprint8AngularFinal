import { LoanType } from './loan-type';

describe('LoanType', () => {
  it('should create an instance', () => {
    expect(new LoanType()).toBeTruthy();
  });
});
