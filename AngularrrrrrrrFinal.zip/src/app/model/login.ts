export class Login {
    userId: String;
    password : String;
    role: String
 
}


