export class Customer {
    uci: number;
    userId: string;
    password: string;
    firstName: string;
    lastname: string;
    fatherName: string;
    motherName: string;
    dateofBirth: Date;
    emailId: string;
    gender: string;
    mobileNumber: number;
    alternateMobileNumber: number;
    aadharNumber: string;
    applicantId: number;


	

}
