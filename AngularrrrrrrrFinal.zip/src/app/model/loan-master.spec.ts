import { LoanMaster } from './loan-master';

describe('LoanMaster', () => {
  it('should create an instance', () => {
    expect(new LoanMaster()).toBeTruthy();
  });
});
