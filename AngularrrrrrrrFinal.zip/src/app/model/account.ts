export class Account {
    accNo: number;
    balance: number;
    accCreationDate: Date;
    accStatus: String;
    accType: String;

}
