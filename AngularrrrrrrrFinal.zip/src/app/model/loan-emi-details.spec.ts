import { LoanEmiDetails } from './loan-emi-details';

describe('LoanEmiDetails', () => {
  it('should create an instance', () => {
    expect(new LoanEmiDetails()).toBeTruthy();
  });
});
