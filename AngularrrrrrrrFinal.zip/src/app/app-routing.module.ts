import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginVerifyComponent} from 'src/app/login-verify/login-verify.component';
import { HomeComponent } from 'src/app/home/home.component';
import{CalculateEmiComponent} from 'src/app/calculate-emi/calculate-emi.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { ApplyloanComponent } from './apply-loan/applyloan.component';
import { BankerDashboardComponent } from './banker-dashboard/banker-dashboard.component';
import { PayEmiComponent } from './pay-emi/pay-emi.component';
import { LoanApprovalComponent } from './loan-approval/loan-approval.component';
import { PreclosureApprovalComponent } from './preclosure-approval/preclosure-approval.component';
import { ViewhistoryComponent } from './view-history/viewhistory.component';


const routes: Routes = [
  {path:'login',component:LoginVerifyComponent},
  {path:'calcEmi/login',component:LoginVerifyComponent},
  {path:'',component:HomeComponent,pathMatch:'full'},
  {path:'calcEmi',component:CalculateEmiComponent},
  {path:'custDashboard', component:CustomerDashboardComponent},
  {path:'applyLoan',component:ApplyloanComponent},
  {path:'bankDashboard', component:BankerDashboardComponent},
  {path: 'custDashboard/payemi', component:PayEmiComponent},
  {path:'approveLoan', component:LoanApprovalComponent},
  {path:'approvePreClosure', component:PreclosureApprovalComponent},
  {path:'custDashboard/viewHistory', component:ViewhistoryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
 }
