import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { LoanApprovalComponent } from './loan-approval/loan-approval.component';
import { PreclosureApprovalComponent } from './preclosure-approval/preclosure-approval.component';
import { ApplyloanComponent } from 'src/app/apply-loan/applyloan.component';
import { ViewhistoryComponent } from 'src/app/view-history/viewhistory.component';
import { PayEmiComponent } from './pay-emi/pay-emi.component';
import { ApplyPreclosureComponent } from './apply-preclosure/apply-preclosure.component';
import { CalculateEmiComponent } from './calculate-emi/calculate-emi.component';
import { LoanDetailsComponent } from './loan-details/loan-details.component';
import { LoginVerifyComponent } from './login-verify/login-verify.component';
import { BankerDashboardComponent } from './banker-dashboard/banker-dashboard.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminDashboardComponent,
    CustomerDashboardComponent,
    LoanApprovalComponent,
    PreclosureApprovalComponent,
    ApplyloanComponent,
    ViewhistoryComponent,
    PayEmiComponent,
    ApplyPreclosureComponent,
    CalculateEmiComponent,
    LoanDetailsComponent,
    LoginVerifyComponent,
    BankerDashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
