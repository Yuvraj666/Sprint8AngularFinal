import { Component, OnInit } from '@angular/core';
import { Banker } from '../model/banker';
import { BankerService } from '../service/banker.service';
import { LoanMaster } from '../model/loan-master';

@Component({
  selector: 'app-preclosure-approval',
  templateUrl: './preclosure-approval.component.html',
  styleUrls: ['./preclosure-approval.component.css']
})
export class PreclosureApprovalComponent implements OnInit {
  loggedInBanker: Banker;
  preClosureApplied:LoanMaster[];
  loanAppSelected:boolean;
  selectLoan:LoanMaster;
  isLoanApproved:boolean;
  isLoanDeclined:boolean;
  verifiedLoan:LoanMaster;

  constructor(private bankerService: BankerService) { 
    this.preClosureApplied=[];
    this.loanAppSelected=false;
    this.selectLoan=new LoanMaster();
    this.isLoanApproved=false;
    this.isLoanDeclined=false;
    this.verifiedLoan=new LoanMaster();
  }

  ngOnInit() {
    this.loggedInBanker = this.bankerService.loggedInBanker;
    this.loadVerificationPreClosures();
    console.log(this.preClosureApplied);
  }

  loadVerificationPreClosures() {
    this.bankerService.getPreClosureAppliedPerBanker(this.bankerService.loggedInBanker.userId).subscribe(
      (data) => {
        this.preClosureApplied = data;
        console.log(this.preClosureApplied);
      }
    );
  }

  onLoanAppSelection() {
    this.loanAppSelected = true;
    console.log(this.selectLoan.applicationNumber);
  }
  
  approve(choice:number) {
    console.log(this.selectLoan);
    if (this.selectLoan.applicationNumber == null) {
      this.isLoanApproved = false;
      this.isLoanDeclined = false;
      alert("Please select a pre-closure for verification.");
    }
    else {
      console.log(choice);
      console.log(this.selectLoan);
      this.bankerService.verifyPreClosure(this.selectLoan, choice).subscribe(
        (data) => {
          this.verifiedLoan = data;
          console.log(this.verifiedLoan);
        }
      );
      if (choice == 1) {
        this.isLoanApproved = true;
        this.isLoanDeclined = false;
      } else {
        this.isLoanApproved = false;
        this.isLoanDeclined = true;
      }
    }
  }
}
