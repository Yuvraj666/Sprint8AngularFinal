import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreclosureApprovalComponent } from './preclosure-approval.component';

describe('PreclosureApprovalComponent', () => {
  let component: PreclosureApprovalComponent;
  let fixture: ComponentFixture<PreclosureApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreclosureApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreclosureApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
