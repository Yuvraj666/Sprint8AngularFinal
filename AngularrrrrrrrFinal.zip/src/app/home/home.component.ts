import { Component, OnInit } from '@angular/core';
import { LoanType } from '../model/loan-type';
import { VisitorService } from '../service/visitor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  loanTypeSpec: LoanType
  typeId: number

  constructor(private visitorServ: VisitorService,
    private router: Router) {
    this.loanTypeSpec = new LoanType();
  }

  ngOnInit() {

  }

  setTypeId(typeId: number) {
    this.visitorServ.typeId = typeId;
    this.router.navigateByUrl('/calcEmi');
  }
}
