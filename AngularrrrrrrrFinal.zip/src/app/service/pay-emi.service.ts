import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoanMaster } from '../model/loan-master';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Customer } from '../model/customer';
import { Account } from '../model/account';

@Injectable({
  providedIn: 'root'
})
export class PayEmiService {

  baseUrl: string;

  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/IBS/Customer`;
  }

  getEmiDueLoans(customer: Customer): Observable<LoanMaster[]> {
    console.log(customer.userId);
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/applicableEmiLoans/${customer.userId}`);
  }

  fetchAcc(loan:LoanMaster):Observable<Account[]> {
    console.log(loan);
    return this.http.post<Account[]>(`${this.baseUrl}/emiSavingsAcc`,loan);
  }

  payEmi(loan:LoanMaster):Observable<LoanMaster> {
    console.log(loan);
    return this.http.post<LoanMaster>(`${this.baseUrl}/payEmi`,loan);
  }

}