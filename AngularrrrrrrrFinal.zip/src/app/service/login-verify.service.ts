import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Login } from '../model/login';
import { BehaviorSubject } from 'rxjs';
import {Customer} from 'src/app/model/customer';
import { ApplyLoanService } from './apply-loan.service';
import { CustomerService } from './customer.service';

@Injectable({
  providedIn: 'root'
})
export class LoginVerifyService {
  baseUrl: string;
  loggedInUser: any;

  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/IBS`;
    this.loggedInUser = null;
  }

  login(login:Login):Observable<Login>{
    return this.http.post<any>(this.baseUrl,login);
  }  
}
