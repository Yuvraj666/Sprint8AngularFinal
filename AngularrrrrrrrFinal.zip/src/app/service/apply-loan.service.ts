import { Injectable, Output, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { LoanType } from 'src/app/model/loan-type';
import { LoanMaster } from '../model/loan-master';
import { LoanEmiDetails } from '../model/loan-emi-details';
import { BehaviorSubject } from 'rxjs';
import { Customer } from '../model/customer';
 
@Injectable({
  providedIn: 'root'
})
export class ApplyLoanService  {
 
  baseUrl: string;
  typeId: number;

  loggedInCustomer : Customer;

  private typeSource = new BehaviorSubject<number>(this.typeId);
  currenttypeId = this.typeSource.asObservable();
 
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/IBS`;
    this.loggedInCustomer = new Customer();
  }
  setTypeId(n: number) {
    this.typeId = n;
    console.log(this.typeId);
  }

  getTypeId() {
    return this.typeId;
  }

  changeTypeId(typeId: number) {
    this.typeSource.next(typeId);
  }

  getLoanTypeById(n: number): Observable<LoanType> {
    return this.http.get<LoanType>(`${this.baseUrl}/${n}`);
  }

  getDisplay(loan: LoanMaster): Observable<LoanEmiDetails[]> {
    return this.http.post<LoanEmiDetails[]>(`${this.baseUrl}/table`,loan);
  }

  getSavingsAcc(userId:string):Observable<Account[]>{
    return this.http.get<Account[]>(`${this.baseUrl}/${userId}`);
  }

  applyLoan(loanMaster: LoanMaster):Observable<LoanMaster>{
    return this.http.post<LoanMaster>(`${this.baseUrl}/applyLoan`, loanMaster);
  }

  saveLoggedInCustomer (loggedInUser : any){
    this.loggedInCustomer = loggedInUser;
    console.log(this.loggedInCustomer);
    }

  getLoggedInCustomer(){
    console.log(this.loggedInCustomer);
    return this.loggedInCustomer;
  }
}