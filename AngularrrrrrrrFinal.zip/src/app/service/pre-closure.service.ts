import { Injectable } from '@angular/core';
import { LoanMaster } from '../model/loan-master';
import { Customer } from '../model/customer';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { Account } from '../model/account';


@Injectable({
  providedIn: 'root'
})
export class PreClosureService {
 
  

  baseUrl: string;

  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/IBS/Customer`;
  }

  getPreClosureLoans(customer: Customer): Observable<LoanMaster[]> {
    console.log(customer.userId);
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/applicablePreClosure/${customer.userId}`);
  }

  fetchAcc(loan:LoanMaster):Observable<Account[]> {
    console.log(loan);
    return this.http.post<Account[]>(`${this.baseUrl}/preClosureSavingsAcc`,loan);
  }

  payPreClosure(loan:LoanMaster):Observable<LoanMaster> {
    console.log(loan);
    return this.http.post<LoanMaster>(`${this.baseUrl}/applyPreClosure`,loan);
  }
  
}
