import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { LoanType } from 'src/app/model/loan-type';
import { Customer } from '../model/customer';
import { LoanEmiDetails } from '../model/loan-emi-details';
import { LoanMaster } from '../model/loan-master';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  typeId: number;
  baseUrl: string;
  loggedInCustomer: Customer;
  savedloanType : LoanType;

  constructor(private http: HttpClient,private router:Router) {
    this.baseUrl = `${environment.baseMwUrl}/IBS`;
  }

  getLoanTypeById(): Observable<LoanType> {
    return this.http.get<LoanType>(`${this.baseUrl}/${this.typeId}`);
  }

  getEmiTableDetails(loan: LoanMaster): Observable<LoanEmiDetails[]> {
    return this.http.post<LoanEmiDetails[]>(`${this.baseUrl}/table`, loan);
  }

  getSavingsAcc(userId: string): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/Customer/${userId}`);
  }

  applyLoan(loanMaster: LoanMaster):Observable<LoanMaster>{
    return this.http.post<LoanMaster>(`${this.baseUrl}/Customer/applyLoan`, loanMaster);
  }

  logoutCustomer(){
    this.loggedInCustomer = undefined;
    sessionStorage.removeItem('userId');
    console.log(this.loggedInCustomer);
    this.router.navigateByUrl("/");
  }
  goToPayEmi(){
    this.router.navigateByUrl("custDashboard/payemi")
  }

  goToHome(){
    this.router.navigateByUrl("custDashboard")
  }

  goToViewHistory(){
    this.router.navigateByUrl("custDashboard/viewHistory")
  }

  goToApplyPreClosure(){
    this.router.navigateByUrl("custDashboard/applypreclosure")
  }
}
