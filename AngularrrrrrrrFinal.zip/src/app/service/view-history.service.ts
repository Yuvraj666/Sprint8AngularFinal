import { Injectable } from '@angular/core';
import { Customer } from '../model/customer';
import { LoanMaster } from '../model/loan-master';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
 
@Injectable({
  providedIn: 'root'
})
export class ViewHistoryService {
 
  baseUrl: string;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/IBS/Customer`;
  }
  getLoans(loggedInCustomer: Customer): Observable<LoanMaster[]> {
    return this.http.get<LoanMaster[]>(`${this.baseUrl}/viewHistory/${loggedInCustomer.userId}`);
  }
 
}