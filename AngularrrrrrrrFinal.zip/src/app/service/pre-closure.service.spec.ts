import { TestBed } from '@angular/core/testing';

import { PreClosureService } from './pre-closure.service';

describe('PreClosureService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PreClosureService = TestBed.get(PreClosureService);
    expect(service).toBeTruthy();
  });
});
