import { Component, OnInit, Input } from '@angular/core';
import { ApplyLoanService } from '../service/apply-loan.service';
import { LoanMaster } from '../model/loan-master';
import { LoanEmiDetails } from '../model/loan-emi-details';
import { Customer } from '../model/customer';
import { VisitorService } from '../service/visitor.service';
import { LoanType } from '../model/loan-type';
import { LoginVerifyService } from '../service/login-verify.service';
import { CustomerService } from '../service/customer.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-applyloan',
  templateUrl: './applyloan.component.html',
  styleUrls: ['./applyloan.component.css']
})
export class ApplyloanComponent implements OnInit {

  newLoan: LoanMaster;
  rate: number;
  onePlusRPoweredN: number;
  emiAmount: number;
  emiAmountFinal: string;
  isEmiCheck: boolean;
  isViewDetails: boolean;
  paidInterest: number;
  paidPrinciple: number;
  emiDetails: LoanEmiDetails[];
  customer: any;
  savAcc: Account[];
  isSavAcc: boolean;
  appLoan: LoanMaster;
  isLoanApplied: boolean;
  typeId: number;
  loanType: LoanType;
  limitCheck: boolean;
  tenureLimitCheck: boolean;
  maxLimit: number;
  minLimit: number;
  emiButtonClicked: boolean;
  viewDetailsClicked: boolean;
  loggedInCustomer: Customer;
  radiogroup: number;
  savingsAccountSelected: boolean;
  

  constructor(
    private customerService: CustomerService,
    private loginVerifyService: LoginVerifyService,private router: Router) {
    this.newLoan = new LoanMaster();
    this.loanType = new LoanType();
    this.isEmiCheck = false;
    this.emiDetails = [];
    this.isViewDetails = false;
    this.savAcc = [];
    this.isSavAcc = false;
    this.limitCheck = false;
    this.tenureLimitCheck = false;
    this.maxLimit = 0;
    this.minLimit = 0;
    this.rate = 0;
    this.emiButtonClicked = false;
    this.radiogroup = 0;
    this.savingsAccountSelected = false;
  }

  ngOnInit() {
    this.getLoanTypeById();
    if(this.loanType == undefined){
      this.loanType = this.customerService.savedloanType;
    }
    this.loggedInCustomer = this.customerService.loggedInCustomer;
    console.log(this.loggedInCustomer);
  }
  getLoanTypeById() {
    this.customerService.getLoanTypeById().subscribe(
      (data) => {
        this.loanType = data;
        this.customerService.savedloanType = this.loanType;
      }
    );
  }

  checkLimits() {
    this.isEmiCheck = false;
    this.isViewDetails = false;
    this.maxLimit = this.loanType.maximumLimit;
    this.minLimit = this.loanType.minimumLimit;
    console.log(this.maxLimit);
    if (this.newLoan.loanAmount <= this.maxLimit && this.newLoan.loanAmount >= this.minLimit) {
      this.isEmiCheck = false;
      this.limitCheck = false;
    } else {
      this.limitCheck = true;
    }
    console.log(this.limitCheck);
  }
  checkTenureLimits() {
    this.isEmiCheck = false;
    this.isViewDetails = false;
    this.emiButtonClicked = false;
    console.log(this.emiButtonClicked);
    if (this.newLoan.loanTenure <= 240 && this.newLoan.loanAmount >= 1) {
      this.isEmiCheck = true;
      this.tenureLimitCheck = false;
    } else {
      this.isEmiCheck = false;
      this.tenureLimitCheck = true;
    }
    console.log(this.tenureLimitCheck);
  }

  calcEmi() {
    this.isEmiCheck = true;
    this.emiButtonClicked = true;
    this.rate = this.loanType.interestRate;
    this.onePlusRPoweredN = Math.pow(((this.rate / 1200) + 1), this.newLoan.loanTenure);
    this.emiAmount = (this.newLoan.loanAmount) * ((this.rate / 1200 * this.onePlusRPoweredN) / (this.onePlusRPoweredN - 1));
    this.newLoan.emiAmount = this.emiAmount;
    this.newLoan.balance = this.newLoan.loanAmount;
    this.newLoan.loanInterest = this.rate;
    this.emiAmountFinal = (this.emiAmount).toFixed(2);
    return this.emiAmountFinal;
  }

  viewDetails() {
    this.isViewDetails = true;
    this.viewDetailsClicked = true;
    this.customerService.getEmiTableDetails(this.newLoan).subscribe(
      (data) => {
        this.emiDetails = data;
      }
    );
  }

  selectSavingsAcc() {
    this.isSavAcc = true;
    this.loggedInCustomer = this.customerService.loggedInCustomer;
    this.customerService.getSavingsAcc(this.loggedInCustomer.userId).subscribe(
      (data) => {
        this.savAcc = data;
      }
    );
    console.log(this.savAcc);
  }

  onLoanAppSelection() {
    this.savingsAccountSelected = true;
    console.log(this.newLoan.savingsAccount);
  }

  logoutCustomer(){
    this.customerService.loggedInCustomer = undefined;
    sessionStorage.removeItem('userId');
    console.log(this.customerService.loggedInCustomer);
    this.router.navigateByUrl("/");    
  }

  applyLoan() {
    console.log(this.newLoan);
    if (this.newLoan.savingsAccount == null) {
      this.isLoanApplied = false;
      alert("Please select a savings account for the loan.");
    }
    else {
      this.newLoan.customerUserId = this.customerService.loggedInCustomer.userId;
      this.isLoanApplied = true;
      console.log(this.newLoan);
      this.customerService.applyLoan(this.newLoan).subscribe(
        (data) => {
          this.appLoan = data;
        }
      )
      if(this.isLoanApplied){ 
        alert( "Your Loan has been applied and your Application Number is: " + this.appLoan.applicationNumber)
      }else{
        alert("Internal Error")
      }
     
    }
  }
  gotoPayEmi(){
    this.customerService.goToPayEmi();
  }
  gotoViewHistory(){
    this.customerService.goToViewHistory();
  }
  gotoApplyPreClosure(){
    this.customerService.goToApplyPreClosure();
  }

}