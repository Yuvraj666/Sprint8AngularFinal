export const environment = {
  production: true,
  baseMwUrl:'http://10.102.54.139:6797'
};